IRWIN SHINE CO. WEBSITE

Upload everything in this folder to your web host.

IMPORTANT:
- index.html is the homepage.
- logo.png is the company logo used by the website.
- Keep index.html and logo.png in the same folder.

The website is already set up with:
Phone: 079230036084
Email: anthonywin2006@gmail.com
Service area: Belfast

Pricing:
Regular Clean — From £25/hour
Deep Clean — From £90
End of Tenancy — From £120
